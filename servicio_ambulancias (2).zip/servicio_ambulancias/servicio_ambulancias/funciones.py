

import re
from datetime import date, datetime

from mysql.connector import errors

from conexion import ErrorConexion, obtener_conexion

# ---------------------------------------------------------------------
# REGLAS DE VALIDACIÓN POR TABLA
# Los nombres de tabla y de columna que se usan en el SQL salen de aquí,
# nunca de lo que escribe el usuario (así se evita la inyección SQL).
# Los VALORES siempre se envían como parámetros (%s).
# ---------------------------------------------------------------------

ESTADOS_AMBULANCIA = ["Disponible", "En servicio", "Mantenimiento", "Fuera de servicio"]
ESTADOS_CONDUCTOR = ["Activo", "Inactivo"]
ESTADOS_SERVICIO = ["Solicitado", "En curso", "Finalizado", "Cancelado"]

PATRON_PLACA = r"[A-Z]{3}[0-9]{3}"
PATRON_NOMBRE = r"[A-Za-zÁÉÍÓÚÜÑáéíóúüñ' ]+"
PATRON_TELEFONO = r"[0-9]{7,15}"
PATRON_DOCUMENTO = r"[0-9]{5,20}"
PATRON_LICENCIA = r"[A-Za-z0-9]{5,20}"

TABLAS = {
    "ambulancias": {
        "pk": "id_ambulancia",
        "singular": "Ambulancia",
        "articulo": "la",
        "sufijo": "a",  # para "registrada", "actualizada", "indicada"
        "clave_lista": "ambulancias",
        "clave_uno": "ambulancia",
        "unicos": {"placa": "Ya existe una ambulancia con esa placa"},
        "campos": {
            "placa": {"tipo": "texto", "max": 10, "mayusculas": True,
                      "patron": PATRON_PLACA,
                      "ayuda": "La placa debe tener 3 letras y 3 números (ejemplo: ABC123)"},
            "tipo": {"tipo": "texto", "permitidos": ["TAB", "TAM"]},
            "estado": {"tipo": "texto", "permitidos": ESTADOS_AMBULANCIA,
                       "defecto": "Disponible"},
        },
    },
    "pacientes": {
        "pk": "id_paciente",
        "singular": "Paciente",
        "articulo": "el",
        "sufijo": "o",
        "clave_lista": "pacientes",
        "clave_uno": "paciente",
        "unicos": {"documento": "Ya existe un paciente con ese documento"},
        "campos": {
            "documento": {"tipo": "texto", "max": 20, "patron": PATRON_DOCUMENTO,
                          "ayuda": "El documento debe tener solo números (entre 5 y 20 dígitos)"},
            "nombre": {"tipo": "texto", "max": 60, "patron": PATRON_NOMBRE,
                       "ayuda": "El nombre solo puede tener letras y espacios"},
            "apellido": {"tipo": "texto", "max": 60, "patron": PATRON_NOMBRE,
                         "ayuda": "El apellido solo puede tener letras y espacios"},
            "fecha_nacimiento": {"tipo": "fecha"},
            "telefono": {"tipo": "texto", "max": 15, "patron": PATRON_TELEFONO,
                         "ayuda": "El teléfono debe tener solo números (entre 7 y 15 dígitos)"},
            "direccion": {"tipo": "texto", "max": 120, "opcional": True},
        },
    },
    "conductores": {
        "pk": "id_conductor",
        "singular": "Conductor",
        "articulo": "el",
        "sufijo": "o",
        "clave_lista": "conductores",
        "clave_uno": "conductor",
        "unicos": {
            "documento": "Ya existe un conductor con ese documento",
            "licencia": "Ya existe un conductor con esa licencia",
        },
        "campos": {
            "documento": {"tipo": "texto", "max": 20, "patron": PATRON_DOCUMENTO,
                          "ayuda": "El documento debe tener solo números (entre 5 y 20 dígitos)"},
            "nombre": {"tipo": "texto", "max": 60, "patron": PATRON_NOMBRE,
                       "ayuda": "El nombre solo puede tener letras y espacios"},
            "apellido": {"tipo": "texto", "max": 60, "patron": PATRON_NOMBRE,
                         "ayuda": "El apellido solo puede tener letras y espacios"},
            "telefono": {"tipo": "texto", "max": 15, "patron": PATRON_TELEFONO,
                         "ayuda": "El teléfono debe tener solo números (entre 7 y 15 dígitos)"},
            "licencia": {"tipo": "texto", "max": 20, "mayusculas": True,
                         "patron": PATRON_LICENCIA,
                         "ayuda": "La licencia debe tener entre 5 y 20 letras o números"},
            "estado": {"tipo": "texto", "permitidos": ESTADOS_CONDUCTOR,
                       "defecto": "Activo"},
        },
    },
    "servicios": {
        "pk": "id_servicio",
        "singular": "Servicio",
        "articulo": "el",
        "sufijo": "o",
        "clave_lista": "servicios",
        "clave_uno": "servicio",
        "unicos": {},
        "campos": {
            "id_ambulancia": {"tipo": "entero", "fk": "ambulancias"},
            "id_paciente": {"tipo": "entero", "fk": "pacientes"},
            "id_conductor": {"tipo": "entero", "fk": "conductores"},
            "origen": {"tipo": "texto", "max": 120},
            "destino": {"tipo": "texto", "max": 120},
            "estado": {"tipo": "texto", "permitidos": ESTADOS_SERVICIO,
                       "defecto": "Solicitado"},
            "observaciones": {"tipo": "texto", "max": 255, "opcional": True},
        },
    },
}

# Se agrega el nombre de la tabla dentro de cada configuración
for _nombre, _config in TABLAS.items():
    _config["tabla"] = _nombre


# ---------------------------------------------------------------------
# VALIDACIONES
# ---------------------------------------------------------------------

def validar_id(valor):
    """Devuelve el ID como número entero positivo, o None si no es válido."""
    if isinstance(valor, str) and valor.isascii() and valor.isdigit():
        numero = int(valor)
        return numero if numero > 0 else None
    return None


def _validar_valor(nombre, regla, valor):
    """
    Valida un solo campo según su regla.
    Devuelve (valor_limpio, mensaje_de_error). Si todo está bien, error es None.
    """
    vacio = valor is None or (isinstance(valor, str) and valor.strip() == "")
    if vacio:
        if regla.get("opcional"):
            return None, None
        return None, f"El campo '{nombre}' no puede estar vacío"

    tipo = regla["tipo"]

    # Números enteros (los ID de las claves foráneas)
    if tipo == "entero":
        if isinstance(valor, bool):
            numero = None
        elif isinstance(valor, int):
            numero = valor
        elif isinstance(valor, str):
            numero = validar_id(valor.strip())
        else:
            numero = None
        if numero is None or numero <= 0:
            return None, f"El campo '{nombre}' debe ser un número entero positivo"
        return numero, None

    # Fechas en formato AAAA-MM-DD
    if tipo == "fecha":
        if not isinstance(valor, str):
            return None, f"El campo '{nombre}' debe ser texto con formato AAAA-MM-DD"
        try:
            fecha = datetime.strptime(valor.strip(), "%Y-%m-%d").date()
        except ValueError:
            return None, (f"El campo '{nombre}' debe tener formato AAAA-MM-DD "
                          "(ejemplo: 1990-05-21)")
        if fecha > date.today() or fecha.year < 1900:
            return None, f"El campo '{nombre}' no es una fecha válida"
        return fecha.isoformat(), None

    # Texto
    if not isinstance(valor, str):
        return None, f"El campo '{nombre}' debe ser texto"
    texto = valor.strip()
    if regla.get("mayusculas"):
        texto = texto.upper()
    if "max" in regla and len(texto) > regla["max"]:
        return None, f"El campo '{nombre}' no puede tener más de {regla['max']} caracteres"
    if "permitidos" in regla:
        permitidos = {p.lower(): p for p in regla["permitidos"]}
        if texto.lower() not in permitidos:
            opciones = ", ".join(regla["permitidos"])
            return None, f"El campo '{nombre}' debe ser uno de: {opciones}"
        texto = permitidos[texto.lower()]
    if "patron" in regla and not re.fullmatch(regla["patron"], texto):
        return None, regla.get("ayuda", f"El campo '{nombre}' tiene un formato inválido")
    return texto, None


def _validar_datos(config, datos, modo):
    """
    Valida el JSON recibido. Modos:
      "crear"      -> todos los campos obligatorios (los que tienen valor
                      por defecto pueden omitirse)
      "reemplazar" -> todos los campos obligatorios (PUT)
      "parcial"    -> basta con enviar uno o más campos (PATCH)
    Devuelve (datos_limpios, mensaje_de_error).
    """
    if not isinstance(datos, dict) or not datos:
        return None, "Debe enviar un JSON válido con los datos"

    campos = config["campos"]
    desconocidos = [c for c in datos if c not in campos]
    if desconocidos:
        permitidos = ", ".join(campos)
        return None, (f"Campos no permitidos: {', '.join(desconocidos)}. "
                      f"Campos válidos: {permitidos}")

    limpios = {}
    faltantes = []
    for nombre, regla in campos.items():
        if nombre in datos:
            valor, error = _validar_valor(nombre, regla, datos[nombre])
            if error:
                return None, error
            limpios[nombre] = valor
        elif modo == "parcial":
            continue
        elif regla.get("opcional"):
            limpios[nombre] = None
        elif modo == "crear" and "defecto" in regla:
            limpios[nombre] = regla["defecto"]
        else:
            faltantes.append(nombre)

    if faltantes:
        return None, f"Faltan campos obligatorios: {', '.join(faltantes)}"
    return limpios, None


# ---------------------------------------------------------------------
# ACCESO A LA BASE DE DATOS
# ---------------------------------------------------------------------

def _ejecutar(sql, parametros=(), consulta=False, uno=False):
    """
    Ejecuta UNA sentencia SQL parametrizada y cierra todo al terminar.
      consulta=True  -> devuelve filas (una sola si uno=True, o None)
      consulta=False -> confirma el cambio y devuelve {"id": ..., "filas": ...}
    Si ocurre un error, deshace el cambio y lo vuelve a lanzar.
    """
    conexion = None
    cursor = None
    try:
        conexion = obtener_conexion()
        cursor = conexion.cursor(dictionary=True)
        cursor.execute(sql, parametros)
        if consulta:
            return cursor.fetchone() if uno else cursor.fetchall()
        conexion.commit()
        return {"id": cursor.lastrowid, "filas": cursor.rowcount}
    except Exception:
        if conexion is not None:
            try:
                conexion.rollback()
            except Exception:
                pass
        raise
    finally:
        if cursor is not None:
            cursor.close()
        if conexion is not None and conexion.is_connected():
            conexion.close()


def _serializar(fila):
    """Convierte fechas a texto para que la fila pueda pasar a JSON."""
    resultado = {}
    for clave, valor in fila.items():
        if isinstance(valor, datetime):
            valor = valor.strftime("%Y-%m-%d %H:%M:%S")
        elif isinstance(valor, date):
            valor = valor.isoformat()
        resultado[clave] = valor
    return resultado


def _buscar_por_id(config, id_registro):
    """Busca un registro por su ID. Devuelve la fila o None si no existe."""
    sql = f"SELECT * FROM {config['tabla']} WHERE {config['pk']} = %s"
    return _ejecutar(sql, (id_registro,), consulta=True, uno=True)


def _no_existe(config):
    """Respuesta estándar de 'registro no encontrado'."""
    texto = f"{config['articulo'].capitalize()} {config['singular'].lower()} no existe"
    return {"error": texto}, 404


def _revisar_id(config, id_texto):
    """
    Valida el ID y comprueba que el registro exista.
    Devuelve (id_numerico, respuesta_de_error). Si todo está bien, la respuesta es None.
    """
    id_registro = validar_id(id_texto)
    if id_registro is None:
        return None, ({"error": "El ID debe ser un número entero positivo"}, 400)
    if _buscar_por_id(config, id_registro) is None:
        return None, _no_existe(config)
    return id_registro, None


def _verificar_referencias(config, limpios):
    """
    Para las claves foráneas (servicios), comprueba que la ambulancia,
    el paciente y el conductor indicados existan. Devuelve un mensaje o None.
    """
    for campo, regla in config["campos"].items():
        tabla_ref = regla.get("fk")
        if tabla_ref and campo in limpios:
            ref = TABLAS[tabla_ref]
            sql = f"SELECT 1 FROM {tabla_ref} WHERE {ref['pk']} = %s"
            if _ejecutar(sql, (limpios[campo],), consulta=True, uno=True) is None:
                return (f"{ref['articulo'].capitalize()} {ref['singular'].lower()} "
                        f"indicad{ref['sufijo']} no existe")
    return None


def _respuesta_error(e, config):
    """Convierte cualquier excepción en una respuesta JSON con su código HTTP."""
    if isinstance(e, ErrorConexion):
        return {"error": "No se pudo conectar a la base de datos", "detalle": str(e)}, 503

    if isinstance(e, errors.Error):
        if e.errno == 1062:  # dato duplicado (placa, documento, licencia)
            for campo, mensaje in config["unicos"].items():
                if f"uq_{config['tabla']}_{campo}" in str(e.msg):
                    return {"error": mensaje}, 409
            return {"error": "Ya existe un registro con esos datos"}, 409
        if e.errno == 1451:  # tiene servicios asociados
            texto = (f"No se puede eliminar {config['articulo']} "
                     f"{config['singular'].lower()} porque tiene servicios asociados")
            return {"error": texto}, 409
        if e.errno == 1452:  # clave foránea inexistente
            return {"error": "La ambulancia, el paciente o el conductor indicado no existe"}, 400
        if e.errno == 3819:  # restricción CHECK de la base de datos
            return {"error": "Hay un dato que no cumple las reglas de la base de datos"}, 400
        return {"error": "Error en la base de datos", "detalle": str(e)}, 500

    return {"error": "Ocurrió un error", "detalle": str(e)}, 500


# ---------------------------------------------------------------------
# FUNCIONES GENÉRICAS (sirven para las 4 tablas)
# ---------------------------------------------------------------------

def crear(tabla, datos):
    """POST: valida los datos y los inserta como un registro nuevo."""
    config = TABLAS[tabla]
    try:
        limpios, error = _validar_datos(config, datos, "crear")
        if error:
            return {"error": error}, 400
        error = _verificar_referencias(config, limpios)
        if error:
            return {"error": error}, 400

        columnas = ", ".join(limpios)
        marcadores = ", ".join(["%s"] * len(limpios))
        sql = f"INSERT INTO {tabla} ({columnas}) VALUES ({marcadores})"
        resultado = _ejecutar(sql, tuple(limpios.values()))
        return {
            "mensaje": f"{config['singular']} registrad{config['sufijo']} correctamente",
            "id": resultado["id"],
        }, 201
    except Exception as e:
        return _respuesta_error(e, config)


def consultar_todos(tabla):
    """GET (lista): devuelve todos los registros de la tabla."""
    config = TABLAS[tabla]
    try:
        sql = f"SELECT * FROM {tabla} ORDER BY {config['pk']}"
        filas = _ejecutar(sql, consulta=True)
        return {
            "total": len(filas),
            config["clave_lista"]: [_serializar(f) for f in filas],
        }, 200
    except Exception as e:
        return _respuesta_error(e, config)


def consultar_uno(tabla, id_texto):
    """GET (uno): devuelve un registro según su ID."""
    config = TABLAS[tabla]
    try:
        id_registro = validar_id(id_texto)
        if id_registro is None:
            return {"error": "El ID debe ser un número entero positivo"}, 400
        fila = _buscar_por_id(config, id_registro)
        if fila is None:
            return _no_existe(config)
        return {config["clave_uno"]: _serializar(fila)}, 200
    except Exception as e:
        return _respuesta_error(e, config)


def _actualizar(tabla, id_texto, datos, modo, verbo):
    """Parte común de PUT y PATCH: valida, comprueba que exista y hace el UPDATE."""
    config = TABLAS[tabla]
    try:
        id_registro, respuesta = _revisar_id(config, id_texto)
        if respuesta:
            return respuesta
        limpios, error = _validar_datos(config, datos, modo)
        if error:
            return {"error": error}, 400
        error = _verificar_referencias(config, limpios)
        if error:
            return {"error": error}, 400

        asignaciones = ", ".join(f"{columna} = %s" for columna in limpios)
        sql = f"UPDATE {tabla} SET {asignaciones} WHERE {config['pk']} = %s"
        _ejecutar(sql, tuple(limpios.values()) + (id_registro,))
        return {
            "mensaje": f"{config['singular']} {verbo}{config['sufijo']} correctamente",
            "id": id_registro,
        }, 200
    except Exception as e:
        return _respuesta_error(e, config)


def reemplazar(tabla, id_texto, datos):
    """PUT: actualiza TODOS los campos del registro (todos son obligatorios)."""
    return _actualizar(tabla, id_texto, datos, "reemplazar", "actualizad")


def modificar(tabla, id_texto, datos):
    """PATCH: actualiza solo los campos enviados."""
    return _actualizar(tabla, id_texto, datos, "parcial", "modificad")


def eliminar(tabla, id_texto):
    """DELETE: elimina el registro si existe y no tiene servicios asociados."""
    config = TABLAS[tabla]
    try:
        id_registro, respuesta = _revisar_id(config, id_texto)
        if respuesta:
            return respuesta
        sql = f"DELETE FROM {tabla} WHERE {config['pk']} = %s"
        _ejecutar(sql, (id_registro,))
        return {
            "mensaje": f"{config['singular']} eliminad{config['sufijo']} correctamente",
            "id": id_registro,
        }, 200
    except Exception as e:
        return _respuesta_error(e, config)


# ---------------------------------------------------------------------
# FUNCIONES POR TABLA (las que usa app.py)
# ---------------------------------------------------------------------

# --- Ambulancias ---

def registrar_ambulancia(datos):
    """Registra una ambulancia nueva (placa, tipo y estado)."""
    return crear("ambulancias", datos)


def consultar_ambulancias():
    """Devuelve la lista de todas las ambulancias."""
    return consultar_todos("ambulancias")


def consultar_ambulancia(id_ambulancia):
    """Devuelve una ambulancia por su ID."""
    return consultar_uno("ambulancias", id_ambulancia)


def actualizar_ambulancia(id_ambulancia, datos):
    """Actualiza completamente una ambulancia (PUT)."""
    return reemplazar("ambulancias", id_ambulancia, datos)


def modificar_ambulancia(id_ambulancia, datos):
    """Modifica solo algunos campos de una ambulancia (PATCH)."""
    return modificar("ambulancias", id_ambulancia, datos)


def cambiar_estado_ambulancia(id_ambulancia, datos):
    """Cambia únicamente el estado de una ambulancia (PATCH /estado)."""
    if not isinstance(datos, dict) or set(datos) != {"estado"}:
        return {"error": "Debe enviar únicamente el campo 'estado'"}, 400
    return modificar("ambulancias", id_ambulancia, datos)


def eliminar_ambulancia(id_ambulancia):
    """Elimina una ambulancia."""
    return eliminar("ambulancias", id_ambulancia)


# --- Pacientes ---

def registrar_paciente(datos):
    """Registra un paciente nuevo."""
    return crear("pacientes", datos)


def consultar_pacientes():
    """Devuelve la lista de todos los pacientes."""
    return consultar_todos("pacientes")


def consultar_paciente(id_paciente):
    """Devuelve un paciente por su ID."""
    return consultar_uno("pacientes", id_paciente)


def actualizar_paciente(id_paciente, datos):
    """Actualiza completamente un paciente (PUT)."""
    return reemplazar("pacientes", id_paciente, datos)


def modificar_paciente(id_paciente, datos):
    """Modifica solo algunos campos de un paciente (PATCH)."""
    return modificar("pacientes", id_paciente, datos)


def eliminar_paciente(id_paciente):
    """Elimina un paciente."""
    return eliminar("pacientes", id_paciente)


# --- Conductores ---

def registrar_conductor(datos):
    """Registra un conductor nuevo."""
    return crear("conductores", datos)


def consultar_conductores():
    """Devuelve la lista de todos los conductores."""
    return consultar_todos("conductores")


def consultar_conductor(id_conductor):
    """Devuelve un conductor por su ID."""
    return consultar_uno("conductores", id_conductor)


def actualizar_conductor(id_conductor, datos):
    """Actualiza completamente un conductor (PUT)."""
    return reemplazar("conductores", id_conductor, datos)


def modificar_conductor(id_conductor, datos):
    """Modifica solo algunos campos de un conductor (PATCH)."""
    return modificar("conductores", id_conductor, datos)


def eliminar_conductor(id_conductor):
    """Elimina un conductor."""
    return eliminar("conductores", id_conductor)


# --- Servicios ---

def registrar_servicio(datos):
    """Registra un servicio (traslado). La ambulancia, el paciente y el conductor deben existir."""
    return crear("servicios", datos)


def consultar_servicios():
    """Devuelve la lista de todos los servicios."""
    return consultar_todos("servicios")


def consultar_servicio(id_servicio):
    """Devuelve un servicio por su ID."""
    return consultar_uno("servicios", id_servicio)


def actualizar_servicio(id_servicio, datos):
    """Actualiza completamente un servicio (PUT)."""
    return reemplazar("servicios", id_servicio, datos)


def modificar_servicio(id_servicio, datos):
    """Modifica solo algunos campos de un servicio (PATCH), por ejemplo su estado."""
    return modificar("servicios", id_servicio, datos)


def eliminar_servicio(id_servicio):
    """Elimina un servicio."""
    return eliminar("servicios", id_servicio)
