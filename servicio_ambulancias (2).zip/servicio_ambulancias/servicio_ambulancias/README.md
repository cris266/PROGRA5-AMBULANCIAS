# Sistema de Servicio de Ambulancias (API)

API hecha con **Python + Flask + MySQL** para gestionar ambulancias, pacientes, conductores y servicios (traslados). No tiene Front-end: todo se usa por peticiones HTTP y todas las respuestas son JSON.

## Estructura del proyecto

```text
servicio_ambulancias/
├── .env              Capa 1: credenciales de la base de datos
├── conexion.py       Capa 2: conexión a MySQL
├── funciones.py      Capa 3: validaciones y consultas SQL
├── app.py            Capa 4: endpoints HTTP (Flask)
├── requirements.txt  Librerías necesarias
├── pruebas.http      Peticiones listas para probar en VS Code


Flujo de una petición:

```text
Cliente HTTP → app.py → funciones.py → conexion.py → MySQL
                                ↑
                    .env (usuario y contraseña)
```

## Requisitos

- Python 3.9 o superior
- MySQL **8.0.16 o superior** (por las restricciones `CHECK`)
- VS Code (opcional: extensión **REST Client** para usar `pruebas.http`)

## Instalación paso a paso

### 1. Crear la base de datos y el usuario

Desde la carpeta del proyecto, en la terminal de VS Code:

```bash
mysql -u root -p < sql/crear_bd.sql
mysql -u root -p < sql/crear_usuario.sql
```

Te pedirá la contraseña de `root` de MySQL. El primer archivo crea la base `servicio_ambulancias` con sus 4 tablas; el segundo crea el usuario `ambulancias_user` con permisos solo de `SELECT, INSERT, UPDATE, DELETE` sobre esa base.

Si usas Windows y el comando `mysql` no se reconoce, abre MySQL Command Line Client o MySQL Workbench y ejecuta el contenido de cada archivo (o usa `source ruta/completa/crear_bd.sql;`).

> Antes de ejecutar `crear_usuario.sql`, cambia `CambiaEstaClave123!` por tu propia contraseña.

### 2. Configurar el `.env`

Abre `.env` y escribe los mismos datos que usaste en MySQL:

```text
DB_HOST=localhost
DB_PORT=3306
DB_NAME=servicio_ambulancias
DB_USER=ambulancias_user
DB_PASSWORD=CambiaEstaClave123!
```

La contraseña **nunca** está escrita en el código Python; `conexion.py` la lee de este archivo. No subas el `.env` a GitHub.

### 3. Instalar las librerías

```bash
python -m venv venv
venv\Scripts\activate          # Windows
# source venv/bin/activate     # Mac / Linux
pip install -r requirements.txt
```

`requirements.txt` instala Flask, mysql-connector-python y **python-dotenv**. Esta última lee el `.env`: en `conexion.py`, `load_dotenv()` carga el archivo y `os.getenv("DB_USER")` obtiene cada valor.

### 4. Ejecutar la API

```bash
python app.py
```

La API queda en `http://127.0.0.1:5000`. Si cambias el código, detén el servidor (Ctrl+C) y vuelve a ejecutarlo.

## Endpoints (25)

Por cada tabla se repiten los 5 métodos HTTP obligatorios (20 en total). Además hay 5 de apoyo: un `GET` por ID en cada tabla y el `PATCH /ambulancias/<id>/estado` que pide la guía.

| Tabla | GET | POST | PUT | PATCH | DELETE | Total obligatorios |
|---|---|---|---|---|---|---|
| Ambulancias | `/ambulancias` | `/ambulancias` | `/ambulancias/<id>` | `/ambulancias/<id>` | `/ambulancias/<id>` | 5 |
| Pacientes | `/pacientes` | `/pacientes` | `/pacientes/<id>` | `/pacientes/<id>` | `/pacientes/<id>` | 5 |
| Conductores | `/conductores` | `/conductores` | `/conductores/<id>` | `/conductores/<id>` | `/conductores/<id>` | 5 |
| Servicios | `/servicios` | `/servicios` | `/servicios/<id>` | `/servicios/<id>` | `/servicios/<id>` | 5 |
| **TOTAL** | | | | | | **20** |

Extras: `GET /<tabla>/<id>` (4) y `PATCH /ambulancias/<id>/estado` (1).

## Reglas de validación

- Campos obligatorios, no vacíos y del tipo correcto; no se aceptan campos desconocidos.
- Placa: 3 letras + 3 números (`ABC123`). Tipo: `TAB` o `TAM`.
- Estados permitidos: ambulancia (`Disponible`, `En servicio`, `Mantenimiento`, `Fuera de servicio`), conductor (`Activo`, `Inactivo`), servicio (`Solicitado`, `En curso`, `Finalizado`, `Cancelado`).
- ID numérico entero positivo; el registro debe existir antes de modificarlo o eliminarlo.
- Un servicio solo se crea si la ambulancia, el paciente y el conductor existen.
- No se puede eliminar una ambulancia, paciente o conductor que ya tenga servicios.
- Placa, documento y licencia no se pueden repetir.

## Códigos HTTP usados

| Código | Cuándo |
|---|---|
| 200 | Consulta, actualización o eliminación correcta |
| 201 | Registro creado |
| 400 | Datos incompletos o inválidos |
| 404 | El registro o la ruta no existe |
| 405 | Método HTTP no permitido |
| 409 | Duplicado (placa, documento, licencia) o registro con servicios asociados |
| 500 | Error SQL o error inesperado |
| 503 | No se pudo conectar a la base de datos |
