
import os

import mysql.connector
from dotenv import load_dotenv

# Lee el archivo .env y carga sus valores como variables de entorno
load_dotenv()


class ErrorConexion(Exception):
    """Error propio para cuando no se puede conectar a la base de datos."""


def obtener_conexion():
    """
    Abre y devuelve una conexión a MySQL usando los datos del .env.
    Si algo falla, lanza ErrorConexion con un mensaje claro.
    Quien llame a esta función debe cerrar la conexión cuando termine.
    """
    try:
        return mysql.connector.connect(
            host=os.getenv("DB_HOST", "localhost"),
            port=int(os.getenv("DB_PORT", "3306")),
            database=os.getenv("DB_NAME"),
            user=os.getenv("DB_USER"),
            password=os.getenv("DB_PASSWORD"),
            connection_timeout=5,
        )
    except Exception as e:
        raise ErrorConexion(f"No se pudo conectar a la base de datos: {e}")
