

from flask import Flask, jsonify, request

import funciones

app = Flask(__name__)
app.json.ensure_ascii = False  # para que las tildes se vean bien en el JSON


def leer_json():
    """Lee el JSON del cuerpo de la petición. Devuelve None si no es un JSON válido."""
    return request.get_json(force=True, silent=True)


def error_500(e):
    """Respuesta JSON para cualquier error inesperado."""
    return jsonify({"error": "Ocurrió un error", "detalle": str(e)}), 500


# --- Errores generales de Flask, también en JSON (nunca HTML) ---

@app.errorhandler(404)
def ruta_no_encontrada(e):
    return jsonify({"error": "La ruta no existe"}), 404


@app.errorhandler(405)
def metodo_no_permitido(e):
    return jsonify({"error": "Método HTTP no permitido para esta ruta"}), 405


@app.errorhandler(500)
def error_interno(e):
    return jsonify({"error": "Error interno del servidor"}), 500

# ======================= AMBULANCIAS =======================

@app.route("/ambulancias", methods=["GET"])
def listar_ambulancias():
    """GET /ambulancias -> lista todos"""
    try:
        datos, codigo = funciones.consultar_ambulancias()
        return jsonify(datos), codigo
    except Exception as e:
        return error_500(e)


@app.route("/ambulancias/<id_ambulancia>", methods=["GET"])
def obtener_ambulancia(id_ambulancia):
    """GET /ambulancias/<id> -> uno solo"""
    try:
        datos, codigo = funciones.consultar_ambulancia(id_ambulancia)
        return jsonify(datos), codigo
    except Exception as e:
        return error_500(e)


@app.route("/ambulancias", methods=["POST"])
def crear_ambulancia():
    """POST /ambulancias -> crea uno nuevo"""
    try:
        datos, codigo = funciones.registrar_ambulancia(leer_json())
        return jsonify(datos), codigo
    except Exception as e:
        return error_500(e)


@app.route("/ambulancias/<id_ambulancia>", methods=["PUT"])
def reemplazar_ambulancia(id_ambulancia):
    """PUT /ambulancias/<id> -> actualiza todos los campos"""
    try:
        datos, codigo = funciones.actualizar_ambulancia(id_ambulancia, leer_json())
        return jsonify(datos), codigo
    except Exception as e:
        return error_500(e)


@app.route("/ambulancias/<id_ambulancia>", methods=["PATCH"])
def modificar_ambulancia(id_ambulancia):
    """PATCH /ambulancias/<id> -> actualiza algunos campos"""
    try:
        datos, codigo = funciones.modificar_ambulancia(id_ambulancia, leer_json())
        return jsonify(datos), codigo
    except Exception as e:
        return error_500(e)


@app.route("/ambulancias/<id_ambulancia>/estado", methods=["PATCH"])
def cambiar_estado(id_ambulancia):
    """PATCH /ambulancias/<id>/estado -> cambia solo el estado"""
    try:
        datos, codigo = funciones.cambiar_estado_ambulancia(id_ambulancia, leer_json())
        return jsonify(datos), codigo
    except Exception as e:
        return error_500(e)


@app.route("/ambulancias/<id_ambulancia>", methods=["DELETE"])
def borrar_ambulancia(id_ambulancia):
    """DELETE /ambulancias/<id> -> elimina"""
    try:
        datos, codigo = funciones.eliminar_ambulancia(id_ambulancia)
        return jsonify(datos), codigo
    except Exception as e:
        return error_500(e)


# ======================= PACIENTES =======================

@app.route("/pacientes", methods=["GET"])
def listar_pacientes():
    """GET /pacientes -> lista todos"""
    try:
        datos, codigo = funciones.consultar_pacientes()
        return jsonify(datos), codigo
    except Exception as e:
        return error_500(e)


@app.route("/pacientes/<id_paciente>", methods=["GET"])
def obtener_paciente(id_paciente):
    """GET /pacientes/<id> -> uno solo"""
    try:
        datos, codigo = funciones.consultar_paciente(id_paciente)
        return jsonify(datos), codigo
    except Exception as e:
        return error_500(e)


@app.route("/pacientes", methods=["POST"])
def crear_paciente():
    """POST /pacientes -> crea uno nuevo"""
    try:
        datos, codigo = funciones.registrar_paciente(leer_json())
        return jsonify(datos), codigo
    except Exception as e:
        return error_500(e)


@app.route("/pacientes/<id_paciente>", methods=["PUT"])
def reemplazar_paciente(id_paciente):
    """PUT /pacientes/<id> -> actualiza todos los campos"""
    try:
        datos, codigo = funciones.actualizar_paciente(id_paciente, leer_json())
        return jsonify(datos), codigo
    except Exception as e:
        return error_500(e)


@app.route("/pacientes/<id_paciente>", methods=["PATCH"])
def modificar_paciente(id_paciente):
    """PATCH /pacientes/<id> -> actualiza algunos campos"""
    try:
        datos, codigo = funciones.modificar_paciente(id_paciente, leer_json())
        return jsonify(datos), codigo
    except Exception as e:
        return error_500(e)


@app.route("/pacientes/<id_paciente>", methods=["DELETE"])
def borrar_paciente(id_paciente):
    """DELETE /pacientes/<id> -> elimina"""
    try:
        datos, codigo = funciones.eliminar_paciente(id_paciente)
        return jsonify(datos), codigo
    except Exception as e:
        return error_500(e)


# ======================= CONDUCTORES =======================

@app.route("/conductores", methods=["GET"])
def listar_conductores():
    """GET /conductores -> lista todos"""
    try:
        datos, codigo = funciones.consultar_conductores()
        return jsonify(datos), codigo
    except Exception as e:
        return error_500(e)


@app.route("/conductores/<id_conductor>", methods=["GET"])
def obtener_conductor(id_conductor):
    """GET /conductores/<id> -> uno solo"""
    try:
        datos, codigo = funciones.consultar_conductor(id_conductor)
        return jsonify(datos), codigo
    except Exception as e:
        return error_500(e)


@app.route("/conductores", methods=["POST"])
def crear_conductor():
    """POST /conductores -> crea uno nuevo"""
    try:
        datos, codigo = funciones.registrar_conductor(leer_json())
        return jsonify(datos), codigo
    except Exception as e:
        return error_500(e)


@app.route("/conductores/<id_conductor>", methods=["PUT"])
def reemplazar_conductor(id_conductor):
    """PUT /conductores/<id> -> actualiza todos los campos"""
    try:
        datos, codigo = funciones.actualizar_conductor(id_conductor, leer_json())
        return jsonify(datos), codigo
    except Exception as e:
        return error_500(e)


@app.route("/conductores/<id_conductor>", methods=["PATCH"])
def modificar_conductor(id_conductor):
    """PATCH /conductores/<id> -> actualiza algunos campos"""
    try:
        datos, codigo = funciones.modificar_conductor(id_conductor, leer_json())
        return jsonify(datos), codigo
    except Exception as e:
        return error_500(e)


@app.route("/conductores/<id_conductor>", methods=["DELETE"])
def borrar_conductor(id_conductor):
    """DELETE /conductores/<id> -> elimina"""
    try:
        datos, codigo = funciones.eliminar_conductor(id_conductor)
        return jsonify(datos), codigo
    except Exception as e:
        return error_500(e)


# ======================= SERVICIOS =======================

@app.route("/servicios", methods=["GET"])
def listar_servicios():
    """GET /servicios -> lista todos"""
    try:
        datos, codigo = funciones.consultar_servicios()
        return jsonify(datos), codigo
    except Exception as e:
        return error_500(e)


@app.route("/servicios/<id_servicio>", methods=["GET"])
def obtener_servicio(id_servicio):
    """GET /servicios/<id> -> uno solo"""
    try:
        datos, codigo = funciones.consultar_servicio(id_servicio)
        return jsonify(datos), codigo
    except Exception as e:
        return error_500(e)


@app.route("/servicios", methods=["POST"])
def crear_servicio():
    """POST /servicios -> crea uno nuevo"""
    try:
        datos, codigo = funciones.registrar_servicio(leer_json())
        return jsonify(datos), codigo
    except Exception as e:
        return error_500(e)


@app.route("/servicios/<id_servicio>", methods=["PUT"])
def reemplazar_servicio(id_servicio):
    """PUT /servicios/<id> -> actualiza todos los campos"""
    try:
        datos, codigo = funciones.actualizar_servicio(id_servicio, leer_json())
        return jsonify(datos), codigo
    except Exception as e:
        return error_500(e)


@app.route("/servicios/<id_servicio>", methods=["PATCH"])
def modificar_servicio(id_servicio):
    """PATCH /servicios/<id> -> actualiza algunos campos"""
    try:
        datos, codigo = funciones.modificar_servicio(id_servicio, leer_json())
        return jsonify(datos), codigo
    except Exception as e:
        return error_500(e)


@app.route("/servicios/<id_servicio>", methods=["DELETE"])
def borrar_servicio(id_servicio):
    """DELETE /servicios/<id> -> elimina"""
    try:
        datos, codigo = funciones.eliminar_servicio(id_servicio)
        return jsonify(datos), codigo
    except Exception as e:
        return error_500(e)


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
